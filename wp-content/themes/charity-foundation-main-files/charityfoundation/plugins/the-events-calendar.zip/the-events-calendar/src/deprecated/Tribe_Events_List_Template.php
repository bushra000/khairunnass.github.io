<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Template__List' );


	class Tribe_Events_List_Template extends Tribe__Events__Template__List {

	}