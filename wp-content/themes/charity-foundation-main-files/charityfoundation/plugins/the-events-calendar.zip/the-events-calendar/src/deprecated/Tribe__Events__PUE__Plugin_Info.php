<?php
_deprecated_file( __FILE__, '4.2', 'Tribe__PUE__Plugin_Info' );


class Tribe__Events__PUE__Plugin_Info extends Tribe__PUE__Plugin_Info {

}