=== CharityFoundation ===
Contributors: nicdark
Requires at least: WordPress 4.4
Tested up to: WordPress 5.5
Version: 2.4
Tags: one-column, two-columns, right-sidebar, custom-header, custom-menu, editor-style, featured-images, microformats, post-formats, rtl-language-support, sticky-post, translation-ready, accessibility-ready

== Description ==
Charity Foundation perfect WP themes for any charity, foundations, hub and non-profit activities.


== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Upload the zip package ( charityfoundation.zip )
3. Click on the 'Activate' button to use your new theme right away.
4. Install required plugins
5. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Copyright ==

Charityfoundation Theme, Copyright 2019 Nicdark Themes

On theme activation, the installation of third-party plugins will be requested. The Nicdark team is not responsible for these plugins which we recommend updating them to the latest version for any problems.